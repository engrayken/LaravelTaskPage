@include('dashboard.nav')
@yield('content')
@include('dashboard.footer')
