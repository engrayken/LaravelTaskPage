<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>


<?php $__env->startSection('name'); ?>

<div class="content">
<div class="row">
<div class="col-md-4 offset-4">
<h4>Login Form</h4>
<hr>
<form action="">
    <div class="form-group">
<input type="text" name="name" id="name" class="form-control">

    </div>
</form>
</div>

</div>

</div>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('home.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mooreAdvice.com\resources\views/home/index.blade.php ENDPATH**/ ?>