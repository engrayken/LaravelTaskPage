<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
</head>
<ul style="background:red; color:white;
display:block">
<li>home</li>
<li>contact</li>
<li>about</li>
<li>dashboard</li>
</ul>
<?php echo $__env->yieldContent('name'); ?>
<footer>copy right</footer>
<?php /**PATH C:\xampp\htdocs\mooreAdvice.com\resources\views/home/app.blade.php ENDPATH**/ ?>