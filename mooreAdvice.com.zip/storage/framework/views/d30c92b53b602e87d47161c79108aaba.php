<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>moorAdvice</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
</head>
<body>

<div class="content">
<div class="row align-items-center vh-100">
<div class="col-md-4 offset-4 border border-1 rounded broder-primary">
<h4>MoorAdvice Login</h4>
<hr>
<form action="<?php echo e(route('loginUser')); ?>" method="POST">
    <?php echo csrf_field(); ?>
<div class="form-group m-4">

    <?php if(Session::has('failed')): ?>
<div class="alert alert-danger"><?php echo e(Session::get('failed')); ?></div>
<?php endif; ?>


<label for="email">Email</label>
<input type="email" name="email" placeholder="Enter Email" value="<?php echo e(old('email')); ?>" class="form-control">
<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
 <div class="text-danger"><?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<label for="password">Password</label>
<input type="password" name="password" placeholder="Enter password" value="<?php echo e(old('password')); ?>" class="form-control">
<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
 <div class="text-danger"><?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<button type="submit" name="submit"  class="btn btn-info mt-1">
    Login </button>
    Not Yet a Member <a href="<?php echo e(route('register')); ?>">Register here</a>

</div>

</form>

</div>

</div>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\mooreAdvice.com\resources\views/auth/login.blade.php ENDPATH**/ ?>