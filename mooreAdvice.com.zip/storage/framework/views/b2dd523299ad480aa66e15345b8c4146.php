<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>moorAdvice Registration</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
</head>
<body>

<div class="content">
<div class="row align-items-center vh-100 rouded">
<div class="col-md-4 offset-4 border border-1 rounded broder-primary">
<h4>MoorAdvice Registration</h4>
<hr>
<form action="<?php echo e(route('registerUser')); ?>" method="POST">
    <?php echo csrf_field(); ?>
<div class="form-group">
<?php if(Session::has('failed')): ?>
<div class="alert alert-danger"><?php echo e(Session::get('failed')); ?></div>
<?php endif; ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php endif; ?>

<label for="fullname">Full Name</label>
<input type="text" name="fullname" placeholder="Enter Full Name" value="<?php echo e(old('fullname')); ?>" class="form-control" required>
<?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
 <div class="text-danger"><?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<label for="email">Email</label>
<input type="email" name="Email" placeholder="Enter Email" value="<?php echo e(old('Email')); ?>" class="form-control" required>
<?php $__errorArgs = ['Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
 <div class="text-danger"><?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<label for="password">Password</label>
<input type="password" name="Password" placeholder="Enter password" value="<?php echo e(old('Password')); ?>" class="form-control" required>
<?php $__errorArgs = ['Password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
 <div class="text-danger"><?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<button type="submit" name="submit"  class="btn btn-info mt-1">
    Register Now </button>

    Already a Member <a href="<?php echo e(route('login')); ?>">Login here</a>
</div>

</form>

</div>

</div>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\mooreAdvice.com\resources\views/auth/register.blade.php ENDPATH**/ ?>